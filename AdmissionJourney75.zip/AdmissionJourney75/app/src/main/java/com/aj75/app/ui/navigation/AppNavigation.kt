package com.aj75.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aj75.app.ui.calendar.CalendarScreen
import com.aj75.app.ui.home.HomeScreen
import com.aj75.app.ui.progress.ProgressScreen
import com.aj75.app.ui.routine.RoutineScreen
import com.aj75.app.ui.settings.SettingsScreen
import com.aj75.app.ui.tools.ToolsScreen

sealed class Tab(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Tab("home", "Home", Icons.Filled.Home)
    data object Routine : Tab("routine", "Routine", Icons.Filled.Checklist)
    data object Progress : Tab("progress", "Progress", Icons.Filled.BarChart)
    data object Calendar : Tab("calendar", "75 Days", Icons.Filled.CalendarMonth)
    data object Tools : Tab("tools", "Tools", Icons.Filled.Timer)
    data object Settings : Tab("settings", "Settings", Icons.Filled.Settings)
}

private val tabs = listOf(Tab.Home, Tab.Routine, Tab.Progress, Tab.Calendar, Tab.Tools, Tab.Settings)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination
                tabs.forEach { tab ->
                    val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Tab.Home.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(Tab.Home.route) { HomeScreen(onNavigateToTab = { route -> navController.navigate(route) }) }
            composable(Tab.Routine.route) { RoutineScreen() }
            composable(Tab.Progress.route) { ProgressScreen() }
            composable(Tab.Calendar.route) { CalendarScreen() }
            composable(Tab.Tools.route) { ToolsScreen() }
            composable(Tab.Settings.route) { SettingsScreen() }
        }
    }
}
